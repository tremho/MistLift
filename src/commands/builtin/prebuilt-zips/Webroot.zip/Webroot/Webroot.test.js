"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tap_1 = __importDefault(require("tap"));
const main_1 = require("./src/main");
const tap_assert_1 = require("@tremho/tap-assert");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
function test(t) {
    return __awaiter(this, void 0, void 0, function* () {
        // copy __testfiles__ to build/functions/Webroot/__files__
        // do two requests.  One empty should find index.html
        // another one for 'foobar' should find a 404
        const buildFiles = path_1.default.join(__dirname, '__files__');
        const testFiles = path_1.default.join(__dirname, '..', '..', '..', 'functions', 'FileServe', '__testfiles__');
        if (fs_1.default.existsSync(buildFiles)) {
            fs_1.default.rmSync(buildFiles, { recursive: true });
        }
        fs_1.default.mkdirSync(buildFiles);
        fs_1.default.copyFileSync(path_1.default.join(path_1.default.normalize(testFiles), 'index.html'), path_1.default.join(path_1.default.normalize(buildFiles), 'index.html'));
        const assert = new tap_assert_1.TapAssert(t);
        let resp = yield (0, main_1.start)({}, {}, null);
        assert.isType(resp, 'object', 'response is an object');
        assert.isEqual(resp.statusCode, 200, 'Success response');
        assert.isEqual(resp.headers['content-type'], 'text/html', 'html content');
        assert.isType(resp.body, 'string', 'Response has a body');
        assert.meetsConstraints(resp.body, 'startsWith=hello world', 'content appears correct');
        assert.isFalse(resp.isBase64Encoded, 'not binary');
        resp = yield (0, main_1.start)({
            request: {
                domainName: "test",
                originalUrl: "foo/bar/baz.goo",
            }
        }, {}, null);
        assert.isType(resp, 'object', 'response is an object');
        assert.isEqual(resp.statusCode, 404, 'Success response');
        assert.isEqual(resp.headers['content-type'], 'text/plain', 'plain content');
        assert.isType(resp.body, 'string', 'Response has a body');
        assert.meetsConstraints(resp.body, 'startsWith=NotFound', 'content appears correct');
        assert.isFalse(resp.isBase64Encoded, 'not binary');
        t.end();
    });
}
tap_1.default.test(path_1.default.basename(__filename), t => {
    test(t);
});
//# sourceMappingURL=Webroot.test.js.map