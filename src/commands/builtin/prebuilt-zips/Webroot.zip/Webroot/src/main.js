"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.start = void 0;
const inverse_y_1 = require("@tremho/inverse-y");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const inverse_y_2 = require("@tremho/inverse-y");
const def = JSON.parse(fs_1.default.readFileSync(path_1.default.join(__dirname, "definition.json")).toString());
const service = new inverse_y_1.LambdaApi(def, (event) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    inverse_y_2.Log.Info("Hit web root");
    const originalUrl = (_a = event === null || event === void 0 ? void 0 : event.request) === null || _a === void 0 ? void 0 : _a.originalUrl;
    inverse_y_2.Log.Info("originalUrl = " + originalUrl);
    let pi = originalUrl.indexOf("://") + 3;
    pi = originalUrl.indexOf('/', pi);
    let file = originalUrl.substring(pi);
    while (file.indexOf('+') !== -1)
        file = file.replace("+", "/");
    if (!file.length)
        file = "/";
    if (file.charAt(file.length - 1) === '/')
        file += 'index.html';
    const filePath = path_1.default.join(__dirname, "..", "__files__", file);
    inverse_y_2.Log.Info("filePath is " + filePath);
    let ext = "";
    let type = "text/plain";
    let skip = false;
    const n = file.lastIndexOf(".");
    if (n !== -1) {
        ext = file.substring(n + 1);
        // todo: a more extensive, configurable mime registry
        if (ext === "html")
            type = "text/html";
        if (ext === "css")
            type = "text/css";
        if (ext === "js")
            type = "text/javascript";
        if (ext === "yaml")
            type = "text/yaml";
        if (ext === "png")
            type = "image/png";
        if (ext === "txt")
            type = "text/plain";
        if (ext === "map")
            skip = true;
    }
    inverse_y_2.Log.Debug(`requesting file:${filePath}, type:${type}`);
    if (!skip && fs_1.default.existsSync(filePath)) {
        const data = fs_1.default.readFileSync(filePath).toString(); // text data
        return (0, inverse_y_1.Success)(data, type);
    }
    else {
        return (0, inverse_y_1.NotFound)(filePath);
    }
}));
function start(e, c, cb) {
    return service.entryPoint(e, c, cb);
}
exports.start = start;
//# sourceMappingURL=main.js.map