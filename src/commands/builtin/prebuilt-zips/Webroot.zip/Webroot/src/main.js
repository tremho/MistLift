"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.start = start;
const inverse_y_1 = require("@tremho/inverse-y");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const def = JSON.parse(fs_1.default.readFileSync(path_1.default.join(__dirname, "definition.json")).toString());
console.warn("page load");
const service = new inverse_y_1.LambdaApi(def, (event) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    inverse_y_1.Log.Info('Webroot handler', { event });
    console.warn("IN WEBROOT HANDLER");
    let redirects = {};
    try {
        const redirMapPath = path_1.default.join(__dirname, "..", "__files__", "redirects.json");
        redirects = JSON.parse(fs_1.default.readFileSync(redirMapPath).toString());
    }
    catch (e) {
        inverse_y_1.Log.error("error while reading redirects ", e);
    }
    inverse_y_1.Log.Info("redirects read ", { redirects });
    let originalUrl = ((_b = (_a = event === null || event === void 0 ? void 0 : event.request) === null || _a === void 0 ? void 0 : _a.originalUrl) !== null && _b !== void 0 ? _b : '').trim();
    inverse_y_1.Log.Info('originalUrl = ' + originalUrl);
    inverse_y_1.Log.Info("testing for test invocation...");
    if (originalUrl.indexOf('{path}.') !== -1) { // test hack 1
        originalUrl = 'https://foo/';
    }
    let pi = originalUrl.indexOf("://") + 3;
    pi = originalUrl.indexOf('/', pi);
    let file = originalUrl.substring(pi);
    inverse_y_1.Log.Trace("testing for custom domain... ", file);
    if (originalUrl.indexOf('.amazonaws.com') === -1) {
        inverse_y_1.Log.Trace("skipping custom domain prefix");
        // if using a custom domain, our url will have the deployment prefix as part of it, so we need to skip that
        if (file.charAt(0) === '/')
            file = file.substring(1);
        file = file.substring(file.indexOf('/') + 1);
    }
    console.warn("resulting file path to be processed ", file);
    if (file === '{path}')
        file = ''; // test hack 2
    inverse_y_1.Log.Info("resulting file path to be processed ", file);
    while (file.indexOf('+') !== -1)
        file = file.replace("+", "/");
    if (!file.length)
        file = "/";
    if (file.charAt(file.length - 1) === '/')
        file += 'index.html';
    const filePath = path_1.default.join(__dirname, "..", "__files__", file);
    inverse_y_1.Log.Info("filePath is " + filePath);
    console.warn("filePath is " + filePath);
    let ext = "";
    let type = "text/plain";
    let skip = false;
    let isBinary = false;
    const n = file.lastIndexOf(".");
    if (n !== -1) {
        ext = file.substring(n + 1);
        // todo: a more extensive, configurable mime registry
        if (ext === "html")
            type = "text/html";
        if (ext === "css")
            type = "text/css";
        if (ext === "js")
            type = "text/javascript";
        if (ext === "yaml")
            type = "text/yaml";
        if (ext === "png") {
            type = "image/png";
            isBinary = true;
        }
        if (ext === "jpg") {
            type = "image/jpeg";
            isBinary = true;
        }
        if (ext === "txt")
            type = "text/plain";
        if (ext === "map")
            skip = true;
    }
    const redirEntry = file.charAt(0) === '/' ? file.substring(1) : file;
    inverse_y_1.Log.Debug("checking redirects for ", { redirEntry });
    const redir = redirects[redirEntry];
    let resp;
    if (redir) {
        inverse_y_1.Log.Info("Redirected to ", { redir });
        resp = { statusCode: 301, headers: { location: redir } };
    }
    else {
        inverse_y_1.Log.Debug(`requesting file:${filePath}, type:${type}`);
        console.warn(`requesting file:${filePath}, type:${type}`);
        if (!skip && fs_1.default.existsSync(filePath)) {
            const data = fs_1.default.readFileSync(filePath).toString(); // text data
            resp = (0, inverse_y_1.Success)(data, type);
        }
        else {
            resp = (0, inverse_y_1.NotFound)(filePath);
        }
    }
    console.warn("Adding CORS headers");
    if (!resp.headers)
        resp.headers = {};
    resp.headers['Access-Control-Allow-Headers'] = "*";
    resp.headers['Access-Control-Allow-Origin'] = "*";
    resp.headers['Access-Control-Allow-Methods'] = "OPTIONS,GET";
    console.warn("Not returning resp due to possible log corruption");
    // console.warn("returning", {resp})
    return resp;
}));
function start(e, c, cb) {
    console.warn("starting webroot handler");
    return service.entryPoint(e, c, cb);
}
function sleep(t) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise(resolve => { setTimeout(() => { resolve(0); }, t); });
    });
}
//# sourceMappingURL=main.js.map