
import { start } from "./src/main.js"

export const handler = async(event) => {

  return await start(event);
};