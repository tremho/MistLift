"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.start = void 0;
const inverse_y_1 = require("@tremho/inverse-y");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const def = JSON.parse(fs_1.default.readFileSync(path_1.default.join(__dirname, "definition.json")).toString());
const service = new inverse_y_1.LambdaApi(def, (event) => __awaiter(void 0, void 0, void 0, function* () {
    inverse_y_1.Log.setMinimumLevel('Console', 'Trace');
    inverse_y_1.Log.Trace("fileserve entry", { event });
    //https://1alu2mimb7.execute-api.us-west-1.amazonaws.com/Dev/docs/apidoc.yaml
    //https://services.tremho.com/identity-tbd/docs/apidoc.yaml
    let url = event.request.originalUrl;
    let ppi = url.indexOf('://') + 3;
    let protocol = url.substring(0, ppi);
    let parts = url.substring(ppi).split('/');
    inverse_y_1.Log.Trace('parts ', { parts });
    let host = parts[0];
    let isAws = host.indexOf('.amazonaws.com') !== -1;
    let file = parts.slice(2).join('+');
    let stage = isAws ? `/${event.stage}/${parts[1]}+` : `/${parts[1]}/`;
    let location = protocol + host + stage + file;
    inverse_y_1.Log.Trace('fileserve deconstruct', { isAws, protocol, host, stage, file, location });
    // redirect to webroot handler
    return { statusCode: 301, headers: { location } };
    // return Success(location)
}));
function start(e, c, cb) {
    return service.entryPoint(e, c, cb);
}
exports.start = start;
//# sourceMappingURL=main.js.map